'use strict';
/**
 * 我的片库 —— 可自由配置的首页插件（home）。
 *
 * 行（= 客户端的一个媒体库）完全由用户在设置页定义，存在插件自己的 data/settings.json：
 *   { id, title, media: 'movie'|'tv', discover: {...TMDB discover 参数...}, recent, pageSize, cacheDuration,
 *     feed?: 'random', randomPage?: N }
 * `discover` 里的键原样拼进 TMDB /discover/{movie|tv}，所以任何 TMDB 支持的筛选都能用。
 * `feed: 'random'` = 把这一行交给客户端首页顶部的**轮播推荐位**（客户端那条查询不带库 Id，
 * 只认显式声明 feed 的行，见面板 ADR-0054）；`randomPage: N` = 每次刷新在 1..N 页里随机挑一页。
 *
 * 契约：framework/contracts/contract-home.md（HomeItem 见第四节）
 * 铁律：失败照实抛、一页按窗口填满、不编数据。
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DEFAULTS = {
  apiBase: 'https://api.tmdb.org/3',
  imageBase: 'https://image.tmdb.org/t/p',
  language: 'zh-CN',
  token: '',
};

/** 剧类默认排除：16 动画 / 99 纪录片 / 10763 新闻 / 10764 真人秀 / 10767 脱口秀
 *  短剧默认排除：TMDB kw 356983「vertical drama」（竖屏短剧，zh 口径下 431 部） */
const NOT_TV = '16,99,10763,10764,10767';
const KW_SHORTDRAMA = '356983';

/** 出厂行（用户没改过设置时用这套；也是「恢复默认」的内容） */
const DEFAULT_ROWS = [
  { id: 'cn_tv', title: '国语剧', media: 'tv', discover: { with_original_language: 'zh', without_genres: NOT_TV, without_keywords: KW_SHORTDRAMA, sort_by: 'popularity.desc' }, recent: 5, pageSize: 20, cacheDuration: 1800 },
  { id: 'cn_variety', title: '国语综艺', media: 'tv', discover: { with_original_language: 'zh', with_genres: '10764|10767', without_keywords: KW_SHORTDRAMA, sort_by: 'popularity.desc' }, recent: 5, pageSize: 20, cacheDuration: 1800 },
  { id: 'cn_short', title: '国语短剧', media: 'tv', discover: { with_original_language: 'zh', with_keywords: KW_SHORTDRAMA, sort_by: 'popularity.desc' }, recent: 5, pageSize: 20, cacheDuration: 1800 },
  { id: 'guoman', title: '国漫', media: 'tv', maxRuntime: 10, discover: { with_original_language: 'zh', with_genres: '16', sort_by: 'popularity.desc' }, recent: 5, pageSize: 20, cacheDuration: 1800 },
  { id: 'cn_movie', title: '国语电影', media: 'movie', discover: { with_original_language: 'zh', without_keywords: KW_SHORTDRAMA, sort_by: 'popularity.desc' }, recent: 5, pageSize: 20, cacheDuration: 1800 },
  { id: 'us_tv', title: '欧美剧', media: 'tv', discover: { with_original_language: 'en', without_genres: NOT_TV, sort_by: 'popularity.desc' }, recent: 5, pageSize: 20, cacheDuration: 1800 },
  { id: 'us_movie', title: '欧美电影', media: 'movie', discover: { with_original_language: 'en', sort_by: 'popularity.desc' }, recent: 5, pageSize: 20, cacheDuration: 1800 },
  { id: 'jpkr_tv', title: '日韩剧', media: 'tv', discover: { with_original_language: 'ja|ko', without_genres: NOT_TV, sort_by: 'popularity.desc' }, recent: 5, pageSize: 20, cacheDuration: 1800 },
  { id: 'jpkr_movie', title: '日韩电影', media: 'movie', discover: { with_original_language: 'ja|ko', sort_by: 'popularity.desc' }, recent: 5, pageSize: 20, cacheDuration: 1800 },
  { id: 'jp_anime', title: '日漫', media: 'tv', discover: { with_original_language: 'ja', with_genres: '16', sort_by: 'popularity.desc' }, recent: 5, pageSize: 20, cacheDuration: 1800 },
  /* 轮播推荐位（客户端首页顶部那条大图，Rex 等）：客户端那条查询**不带库 Id**，
   * 面板只把它交给「显式声明了 feed 的那一行」（见 ADR-0054；没有插件声明就回空、首页没图）。
   * 所以这一行**必须存在且保留 feed: 'random'** —— 删了它轮播就空。
   * 它同时是一个普通库行（Views 里能看到），randomPage 让它每次刷新换一页热门。 */
  {
    id: 'random_picks',
    title: '随机推荐',
    media: 'tv',
    feed: 'random',
    randomPage: 8,
    discover: { with_original_language: 'zh', without_genres: NOT_TV, without_keywords: KW_SHORTDRAMA, 'vote_count.gte': '20', sort_by: 'popularity.desc' },
    recent: 0,
    pageSize: 20,
    cacheDuration: 600,
  },
];

/* ---------------------------------------------------------------- 存储 */

function readSettings(ctx) {
  try {
    return Object.assign({}, DEFAULTS, JSON.parse(fs.readFileSync(path.join(ctx.dataDir, 'settings.json'), 'utf8')));
  } catch {
    return Object.assign({}, DEFAULTS);
  }
}
function writeSettings(ctx, obj) {
  fs.mkdirSync(ctx.dataDir, { recursive: true });
  fs.writeFileSync(path.join(ctx.dataDir, 'settings.json'), JSON.stringify(obj, null, 2));
}

const ROW_ID_RE = /^[a-z0-9][a-z0-9._-]{0,63}$/;

/** 行清单：用户存过的就用用户的，否则出厂。
 *  ⚠️ 兜底：老配置里没有轮播行（2.2.1 之前都没有）→ 补上出厂那一行「随机推荐」。
 *     不补的话客户端首页顶部大图就是空的（客户端只认 feed 行）。第一次在设置页保存后即落盘。 */
function rowsOf(settings) {
  const rows = Array.isArray(settings.rows) ? settings.rows : null;
  const list = rows && rows.length ? rows.slice() : DEFAULT_ROWS.slice();
  if (!list.some((r) => r && r.feed)) {
    const feedRow = DEFAULT_ROWS.find((r) => r.feed);
    if (feedRow) list.push(feedRow);
  }
  return list;
}

/** 归一化一行（设置页提交的东西不可信） */
function normRow(input, usedIds) {
  const src = input && typeof input === 'object' ? input : {};
  const title = String(src.title || '').trim().slice(0, 40) || '未命名库';
  const media = String(src.media || 'movie').toLowerCase() === 'tv' ? 'tv' : 'movie';
  /* maxRuntime：行级「每集时长 ≤ N 分钟就不算正剧/正漫」（tv 用，默认关）。0 = 不过滤。 */
  const maxRuntime = Math.min(120, Math.max(0, Number(src.maxRuntime) || 0));
  const discover = {};
  const raw = src.discover && typeof src.discover === 'object' && !Array.isArray(src.discover) ? src.discover : {};
  for (const [k, v] of Object.entries(raw)) {
    const key = String(k).trim();
    if (!/^[A-Za-z0-9_.]{1,40}$/.test(key)) continue;
    const val = String(v === undefined || v === null ? '' : v).trim();
    if (val) discover[key] = val;
  }
  if (!discover.sort_by) discover.sort_by = 'popularity.desc';
  let id = String(src.id || '').trim().toLowerCase();
  if (!ROW_ID_RE.test(id) || usedIds.has(id)) {
    id = 'row-' + crypto.randomBytes(3).toString('hex');
    while (usedIds.has(id)) id = 'row-' + crypto.randomBytes(3).toString('hex');
  }
  usedIds.add(id);
  const recent = Math.max(0, Math.min(50, Number(src.recent) || 0));
  const pageSize = Math.max(1, Math.min(200, Number(src.pageSize) || 20));
  const cacheDuration = Math.max(0, Math.min(86400, Number(src.cacheDuration) || 0));
  /* feed：交给客户端轮播推荐位的那一行（面板按值精确匹配，认不出就回空）。只收小写短词，
   * 目前面板只会问 'random'；留成开放值，将来面板加别的 feed 不用改插件。
   * randomPage：那一行每次刷新在 1..N 页里随机挑一页（0 = 不随机，永远第一页）。 */
  const feedRaw = String(src.feed || '').trim().toLowerCase();
  const feed = /^[a-z]{1,16}$/.test(feedRaw) ? feedRaw : '';
  const randomPage = feed ? Math.max(0, Math.min(50, Number(src.randomPage) || 0)) : 0;
  return { id, title, media, maxRuntime, discover, recent, pageSize, cacheDuration, feed, randomPage };
}

function normRows(list) {
  const used = new Set();
  return (Array.isArray(list) ? list : []).slice(0, 40).map((r) => normRow(r, used));
}

/* ---------------------------------------------------------------- 上游 */

async function tmdb(ctx, settings, p, query) {
  if (!settings.token) {
    const e = new Error('还没填 TMDB Token（插件设置页填 v4 API Read Access Token）');
    e.code = 'NO_TOKEN';
    throw e;
  }
  const qs = new URLSearchParams(Object.assign({ language: settings.language || 'zh-CN' }, query));
  const url = `${String(settings.apiBase || DEFAULTS.apiBase).replace(/\/+$/, '')}${p}?${qs}`;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 15000);
  try {
    const res = await fetch(url, { headers: { Authorization: 'Bearer ' + settings.token, Accept: 'application/json' }, signal: ctrl.signal });
    const text = await res.text();
    let json = null;
    try {
      json = JSON.parse(text);
    } catch {
      /* 非 JSON */
    }
    if (!res.ok) {
      const e = new Error(`TMDB HTTP ${res.status}${json && json.status_message ? '：' + json.status_message : ''}`);
      e.code = 'UPSTREAM_HTTP';
      e.status = res.status;
      throw e;
    }
    return json || {};
  } catch (err) {
    if (err && err.name === 'AbortError') {
      const e = new Error('TMDB 超时(15000ms)');
      e.code = 'TIMEOUT';
      throw e;
    }
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

function toHomeItem(r, media, settings) {
  const isMovie = media === 'movie';
  const img = String(settings.imageBase || DEFAULTS.imageBase).replace(/\/+$/, '');
  const out = {
    id: `tmdb_${r.id}_${isMovie ? 'movie' : 'tv'}`,
    type: isMovie ? 'movie' : 'tv',
    title: (isMovie ? r.title : r.name) || (isMovie ? r.original_title : r.original_name) || '',
    originalTitle: (isMovie ? r.original_title : r.original_name) || '',
    overview: r.overview || '',
    providerIds: { tmdb: String(r.id) },
  };
  const date = (isMovie ? r.release_date : r.first_air_date) || '';
  const year = Number(String(date).slice(0, 4));
  if (year > 0) out.year = year;
  const rating = Number(r.vote_average);
  if (rating > 0) out.rating = rating;
  if (r.poster_path) out.poster = img + '/w500' + r.poster_path;
  if (r.backdrop_path) out.backdrop = img + '/w780' + r.backdrop_path;
  return out;
}

/* ---------------------------------------------------------------- 过滤：未播出 / 每集时长 */

/** 今天（TMDB 给的是日期不带时区，用本地时区比就够） */
function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

/** 未播出的条目：日期存在且晚于今天 → 不进列表。没有日期的照旧保留（判断不了就不动）。 */
function isUnaired(r, media) {
  const date = String((media === 'movie' ? r.release_date : r.first_air_date) || '');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return false;
  return date > todayStr();
}

const RUNTIME_TTL = 6 * 3600 * 1000;
const runtimeCache = new Map(); // tmdbId -> { at, rt: number|null }

/** 一集的时长（分钟）；查不到/上游没给 → null（不参与过滤） */
async function episodeRuntime(ctx, settings, tmdbId) {
  const hit = runtimeCache.get(tmdbId);
  if (hit && Date.now() - hit.at < RUNTIME_TTL) return hit.rt;
  const rt = await (async () => {
    try {
      const j = await tmdb(ctx, settings, `/tv/${tmdbId}`, {});
      const list = (j || {}).episode_run_time;
      if (!Array.isArray(list) || !list.length) return null;
      return Math.min(...list);
    } catch (e) {
      if (e && e.code === 'TIMEOUT') return null;
      throw e;
    }
  })();
  runtimeCache.set(tmdbId, { at: Date.now(), rt });
  if (runtimeCache.size > 5000) runtimeCache.clear();
  return rt;
}

/** 批量拿一批 tmdbId 的时长（并发 8，够快也够礼貌） */
async function runtimeOfMany(ctx, settings, ids) {
  const need = ids.filter((id) => id != null);
  const out = new Map();
  for (let i = 0; i < need.length; i += 8) {
    const batch = need.slice(i, i + 8);
    // eslint-disable-next-line no-await-in-loop
    const vals = await Promise.all(batch.map((id) => episodeRuntime(ctx, settings, id)));
    batch.forEach((id, k) => out.set(id, vals[k]));
  }
  return out;
}

/* ---------------------------------------------------------------- 缓存 */

const cache = new Map();
function cacheGet(key) {
  const hit = cache.get(key);
  if (!hit) return null;
  if (Date.now() - hit.at > hit.ttl) {
    cache.delete(key);
    return null;
  }
  return hit;
}

/* ---------------------------------------------------------------- 动作 */

const actions = {
  async rows(args, ctx) {
    const rows = rowsOf(readSettings(ctx));
    return {
      ok: true,
      rows: rows.map((r) => {
        const d = {
          id: r.id,
          title: r.title,
          collectionType: r.media === 'tv' ? 'tvshows' : 'movies',
          cacheDuration: r.cacheDuration || 0,
        };
        /* ⚠️ 客户端轮播推荐位（Rex 首页顶部大图）只认这一栏：没有行申报 feed → 回空 → 首页没图 */
        if (r.feed) d.feed = r.feed;
        return d;
      }),
    };
  },

  async run(args, ctx) {
    const rowId = String(args.rowId || '');
    const settings = readSettings(ctx);
    const row = rowsOf(settings).find((r) => r.id === rowId);
    if (!row) {
      const e = new Error('没有这一行：' + rowId);
      e.code = 'NO_ROW';
      throw e;
    }
    const start = Math.max(0, Number(args.startIndex) || 0);
    const limit = Math.min(200, Math.max(1, Number(args.limit) || Number(row.pageSize) || 20));

    const discover = Object.assign({}, row.discover || {});
    const years = Number(row.recent) || 0;
    if (years > 0) {
      const d = new Date();
      d.setFullYear(d.getFullYear() - years);
      discover[row.media === 'tv' ? 'first_air_date.gte' : 'primary_release_date.gte'] = d.toISOString().slice(0, 10);
    }

    const ttlMs = (Number(row.cacheDuration) || 0) * 1000;
    const UP = 20;
    /* 起手页：默认按 startIndex 换算；轮播那一行（randomPage>0）在**首页第一发**时随机挑一页，
     * 这样每次进首页顶部的图都不太一样。startIndex>0（客户端翻页）仍按序走，不跳。 */
    const rp = Math.max(0, Number(row.randomPage) || 0);
    let page = Math.floor(start / UP) + 1;
    let offset = start % UP;
    if (rp > 0 && start === 0) {
      page = 1 + Math.floor(Math.random() * Math.min(50, rp));
      offset = 0;
    }
    const key = `${row.id}:${JSON.stringify(discover)}:${start}:${limit}:${page}`;
    if (ttlMs > 0) {
      const hit = cacheGet(key);
      if (hit) return { items: hit.items, total: hit.total, cached: true };
    }

    const want = offset + limit; /* 过滤后的可见流里，这一窗口要覆盖到 offset+limit */

    /* 从 from 页起往后凑满 want 条。抽成函数是因为**随机页可能越界**：
     * 候选池不到 N 页时 TMDB 回空页 —— 那时必须回落到第一页，
     * 否则轮播就空了（正是这次要修的病）。 */
    const collectFrom = async (from) => {
      let tot = 0;
      const vis = [];
      for (let p = from; vis.length < want && p <= 500; p += 1) {
        // eslint-disable-next-line no-await-in-loop
        const j = await tmdb(ctx, settings, `/discover/${row.media}`, Object.assign({ page: p, include_adult: 'false' }, discover));
        tot = Number(j.total_results) || tot;
        let res = (j.results || []);
        if (res.length === 0) break; /* 越过池尾 → 停 */
        /* ① 未播出（日期晚于今天）→ 不进列表。上游可能在同一页给多个未播条目，继续翻页凑满窗口。 */
        res = res.filter((r) => !isUnaired(r, row.media));
        /* ② 行级「每集时长 ≤ N 分钟就不算正剧/正漫」——要逐条查详情才有长度，批量并发 8。
         *    没时长数据但基本没人评的（vote_count<10）也剔：那正是收录没做全的流水线漫剧；
         *    热门正剧不管新旧都不会没人评，误伤面很小。 */
        if (Number(row.maxRuntime) > 0 && row.media === 'tv' && res.length) {
          // eslint-disable-next-line no-await-in-loop
          const rt = await runtimeOfMany(ctx, settings, res.map((r) => r.id));
          if (rt.size) {
            res = res.filter((r) => {
              const v = rt.get(r.id);
              if (v != null && v <= row.maxRuntime) return false;
              if (v == null && Number(r.vote_count) < 10) return false;
              return true;
            });
          }
        }
        if (res.length === 0) continue; /* 这一页全被滤掉了，看下一页 */
        vis.push(...res);
      }
      return { vis, tot };
    };

    let { vis: visible, tot: total } = await collectFrom(page);
    if (!visible.length && page > 1) {
      /* 随机页越界（池子没那么多页）→ 回落第一页，宁可固定也不空 */
      const fb = await collectFrom(1);
      visible = fb.vis;
      total = fb.tot || total;
      page = 1;
    }
    const slice = visible.slice(offset, want).map((r) => toHomeItem(r, row.media, settings));
    const out = { items: slice, total: total || slice.length };
    if (ttlMs > 0) cache.set(key, Object.assign({ at: Date.now(), ttl: ttlMs }, out));
    return out;
  },

  async http(args, ctx) {
    const method = String(args.method || 'GET').toUpperCase();
    const p = String(args.path || '/').replace(/\/+$/, '') || '/';
    let body = {};
    if (args.body) {
      try {
        body = JSON.parse(args.body);
      } catch {
        return { status: 400, body: { ok: false, error: '请求体不是 JSON' } };
      }
    }
    const settings = readSettings(ctx);

    if (p === '/state' && method === 'GET') {
      return {
        body: {
          settings: {
            apiBase: settings.apiBase,
            imageBase: settings.imageBase,
            language: settings.language,
            token: { set: !!settings.token, length: (settings.token || '').length },
          },
          rows: rowsOf(settings),
          defaults: DEFAULT_ROWS,
          isDefault: !Array.isArray(settings.rows) || !settings.rows.length,
        },
      };
    }

    if (p === '/settings' && method === 'POST') {
      const next = Object.assign({}, settings);
      for (const k of ['apiBase', 'imageBase', 'language']) {
        if (body[k] !== undefined) next[k] = String(body[k] || '').trim() || DEFAULTS[k];
      }
      if (body.token !== undefined) {
        const t = String(body.token || '').trim();
        if (t) next.token = t;
      }
      if (body.clearToken === true) next.token = '';
      writeSettings(ctx, next);
      return { body: { ok: true } };
    }

    /* 保存行清单（整份替换） */
    if (p === '/rows' && method === 'POST') {
      const rows = normRows(body.rows);
      if (!rows.length) return { status: 400, body: { ok: false, error: '至少要留一行' } };
      const next = Object.assign({}, settings, { rows });
      writeSettings(ctx, next);
      return { body: { ok: true, rows } };
    }

    /* 恢复出厂行 */
    if (p === '/rows/reset' && method === 'POST') {
      const next = Object.assign({}, settings);
      delete next.rows;
      writeSettings(ctx, next);
      return { body: { ok: true, rows: DEFAULT_ROWS } };
    }

    /* 试跑一行：{ row, startIndex?, limit? } → { items, total } */
    if (p === '/preview' && method === 'POST') {
      const row = normRow(body.row || {}, new Set());
      const discover = Object.assign({}, row.discover);
      const years = Number(row.recent) || 0;
      if (years > 0) {
        const d = new Date();
        d.setFullYear(d.getFullYear() - years);
        discover[row.media === 'tv' ? 'first_air_date.gte' : 'primary_release_date.gte'] = d.toISOString().slice(0, 10);
      }
      try {
        const j = await tmdb(ctx, settings, `/discover/${row.media}`, Object.assign({ page: 1, include_adult: 'false' }, discover));
        let res = (j.results || []).filter((r) => !isUnaired(r, row.media));
        if (Number(row.maxRuntime) > 0 && row.media === 'tv' && res.length) {
          const rt = await runtimeOfMany(ctx, settings, res.map((r) => r.id));
          res = res.filter((r) => {
            const v = rt.get(r.id);
            if (v != null && v <= row.maxRuntime) return false;
            if (v == null && Number(r.vote_count) < 10) return false;
            return true;
          });
        }
        const items = res.slice(0, 6).map((r) => toHomeItem(r, row.media, settings));
        return { body: { ok: true, total: Number(j.total_results) || 0, items: items.map((i) => ({ title: i.title, year: i.year || 0 })) } };
      } catch (e) {
        return { body: { ok: false, error: (e && e.message) || '失败' } };
      }
    }

    if (p === '/test' && method === 'POST') {
      try {
        const j = await tmdb(ctx, settings, '/discover/movie', { sort_by: 'popularity.desc', page: 1 });
        return { body: { ok: true, total: j.total_results || 0, sample: (j.results || [])[0] ? j.results[0].title || '' : '' } };
      } catch (e) {
        return { body: { ok: false, error: (e && e.message) || '失败' } };
      }
    }

    return { status: 404, body: { ok: false, error: 'no route' } };
  },
};

module.exports = { actions };

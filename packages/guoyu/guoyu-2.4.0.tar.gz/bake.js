'use strict';
/**
 * 运行时给「从这一行选图」的横图**烤字**（压暗 + 库名 + 副标题 + 强调色条）。
 *
 * 为什么要带一套纯 JS 的 JPEG 编解码：插件跑在面板的 node 进程里，环境是零依赖裸 node，
 * 没有 sharp / canvas / ImageMagick / ffmpeg —— 原生图像库一个都没有。所以 vendor 了
 * jpeg-js（MIT，纯 JS，解出 62KB）自己解码、改像素、再编码。
 *
 * 中文字怎么来：JS 里**没有字体光栅化能力**，没法把「国语剧」画出来。办法是把 11 个
 * 出厂行的「库名 + 副标题」在打包前用 Pillow 预烤成**灰度遮罩**（cover-mask/*.bin，
 * zlib 压缩的 8bit 灰度，白字黑底），运行时把遮罩的亮度当 alpha 叠上去 —— 不需要字体。
 * 用户自己加了行/改了行名 → 没有对应遮罩，那就只压暗 + 画色条，不烤字（不报错）。
 *
 * 压暗参数与出厂那批封面完全一致（covers/gen_defaults.py 的 darken()）：
 *   顶部 45% 不动 → 往下按 t^1.6 * 0.82 压暗 → 再叠一层 0~6% 的整体压暗。
 */

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const jpeg = require('./vendor/jpeg-js');

const W = 1280;
const H = 720;
const DARK_BASE = 0.45;
const DARK_POWER = 1.6;
const DARK_AMOUNT = 0.82;
const DARK_FLOOR = 0.06;
const QUALITY = 86;
const MASK_DIR = path.join(__dirname, 'cover-mask');

let idxCache = null;

/** 字模索引（cover-mask/index.json）：行 id → {accent, bar, x/y/w/h, file} */
function masks() {
  if (idxCache) return idxCache;
  try {
    idxCache = JSON.parse(fs.readFileSync(path.join(MASK_DIR, 'index.json'), 'utf8'));
  } catch (e) {
    idxCache = {};
  }
  return idxCache;
}

const maskBufCache = Object.create(null);

function maskOf(rowId) {
  const m = masks()[rowId];
  if (!m) return null;
  if (maskBufCache[rowId]) return Object.assign({ gray: maskBufCache[rowId] }, m);
  try {
    const gray = zlib.inflateSync(fs.readFileSync(path.join(MASK_DIR, m.file)));
    if (gray.length !== m.w * m.h) return null;
    maskBufCache[rowId] = gray;
    return Object.assign({ gray }, m);
  } catch (e) {
    return null;
  }
}

/** 十六进制颜色 → [r,g,b] */
function rgbOf(hex, fallback) {
  const s = String(hex || '').replace('#', '');
  if (!/^[0-9a-f]{6}$/i.test(s)) return fallback || [92, 124, 224];
  return [parseInt(s.slice(0, 2), 16), parseInt(s.slice(2, 4), 16), parseInt(s.slice(4, 6), 16)];
}

/**
 * 等比裁切到 1280×720（cover 语义：占满、居中裁，不拉伸）。
 * 本来就是同尺寸时直接返回原 buffer（最省事的快路径）。
 */
function fitCanvas(img) {
  const sw = img.width;
  const sh = img.height;
  const src = img.data;
  if (sw === W && sh === H) {
    const out = Buffer.alloc(W * H * 4);
    src.copy ? src.copy(out) : out.set(src);
    return out;
  }
  const k = Math.max(W / sw, H / sh);
  const inv = 1 / k;
  const offX = (sw * k - W) / 2;
  const offY = (sh * k - H) / 2;
  const out = Buffer.alloc(W * H * 4);
  for (let y = 0; y < H; y++) {
    const fy = (y + offY) * inv;
    const y0 = Math.max(0, Math.min(sh - 1, Math.floor(fy)));
    const y1 = Math.max(0, Math.min(sh - 1, y0 + 1));
    const wy = Math.max(0, Math.min(1, fy - y0));
    const row0 = y0 * sw;
    const row1 = y1 * sw;
    let o = y * W * 4;
    for (let x = 0; x < W; x++) {
      const fx = (x + offX) * inv;
      const x0 = Math.max(0, Math.min(sw - 1, Math.floor(fx)));
      const x1 = Math.max(0, Math.min(sw - 1, x0 + 1));
      const wx = Math.max(0, Math.min(1, fx - x0));
      const a = (row0 + x0) * 4;
      const b = (row0 + x1) * 4;
      const c = (row1 + x0) * 4;
      const d = (row1 + x1) * 4;
      for (let ch = 0; ch < 3; ch++) {
        const top = src[a + ch] + (src[b + ch] - src[a + ch]) * wx;
        const bot = src[c + ch] + (src[d + ch] - src[c + ch]) * wx;
        out[o + ch] = (top + (bot - top) * wy + 0.5) | 0;
      }
      out[o + 3] = 255;
      o += 4;
    }
  }
  return out;
}

/** 压暗：与出厂封面同一套参数（见文件头） */
function darken(px) {
  for (let y = 0; y < H; y++) {
    const t = (y / H - DARK_BASE) / (1 - DARK_BASE);
    const g = t <= 0 ? 0 : Math.min(1, t) ** DARK_POWER * DARK_AMOUNT;
    const k = 1 - Math.max(g, DARK_FLOOR * (y / H));
    if (k >= 0.999) continue;
    let o = y * W * 4;
    for (let x = 0; x < W; x++) {
      px[o] = (px[o] * k) | 0;
      px[o + 1] = (px[o + 1] * k) | 0;
      px[o + 2] = (px[o + 2] * k) | 0;
      o += 4;
    }
  }
}

/** 把灰度遮罩当 alpha 叠白字（遮罩亮度越低 → 越透明，正好表达副标题的灰） */
function stampMask(px, m) {
  const { gray, x: mx, y: my, w, h } = m;
  for (let y = 0; y < h; y++) {
    const py = my + y;
    if (py < 0 || py >= H) continue;
    for (let x = 0; x < w; x++) {
      const px0 = mx + x;
      if (px0 < 0 || px0 >= W) continue;
      const a = gray[y * w + x];
      if (!a) continue;
      const o = (py * W + px0) * 4;
      if (a === 255) {
        px[o] = px[o + 1] = px[o + 2] = 255;
      } else {
        const f = a / 255;
        px[o] = (px[o] + (255 - px[o]) * f) | 0;
        px[o + 1] = (px[o + 1] + (255 - px[o + 1]) * f) | 0;
        px[o + 2] = (px[o + 2] + (255 - px[o + 2]) * f) | 0;
      }
    }
  }
}

/** 强调色竖条（比文字高一截） */
function drawBar(px, bar, rgb) {
  const [x, y, w, h] = bar;
  for (let yy = y; yy < y + h && yy < H; yy++) {
    let o = (yy * W + x) * 4;
    for (let xx = 0; xx < w && x + xx < W; xx++) {
      px[o] = rgb[0];
      px[o + 1] = rgb[1];
      px[o + 2] = rgb[2];
      px[o + 3] = 255;
      o += 4;
    }
  }
}

/**
 * 主入口：一张原图字节 → 烤好的 JPEG 字节。
 * @returns {{buf: Buffer, baked: boolean, label: string|null}}
 */
function bakeCover(inputBuf, rowId) {
  const t0 = Date.now();
  const img = jpeg.decode(inputBuf, { maxMemoryUsageInMB: 256, formatAsRGBA: true });
  if (!img || !img.width || !img.height) throw new Error('图源解不开（可能不是 JPEG）');
  const px = fitCanvas(img);
  darken(px);
  const m = maskOf(rowId);
  if (m) {
    stampMask(px, m);
    drawBar(px, m.bar, rgbOf(m.accent));
  }
  const out = jpeg.encode({ data: px, width: W, height: H }, QUALITY).data;
  return {
    buf: Buffer.from(out),
    baked: !!m,
    label: m ? m.name : null,
    ms: Date.now() - t0,
    src: `${img.width}×${img.height}`,
  };
}

module.exports = { bakeCover, maskIds: () => Object.keys(masks()) };

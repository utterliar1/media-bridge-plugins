/* 我的片库 · 设置页：行完全可编辑（增删/排序/筛选/试跑） */
const API = location.pathname.replace(/\/ui\/.*$/, '') + '/api';
const $ = (id) => document.getElementById(id);
const el = (tag, attrs, ...kids) => {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k === 'class') n.className = v;
    else if (k === 'text') n.textContent = v;
    else if (k === 'html') n.innerHTML = v;
    else if (k.startsWith('on') && typeof v === 'function') n.addEventListener(k.slice(2), v);
    /* ↑ 事件必须 addEventListener：setAttribute('onclick', fn) 只会把函数 toString 成属性字符串，
     *   点击时什么也不会发生（试跑/上移/下移/删除这几个按钮一直没生效就是它）。 */
    else n.setAttribute(k, v);
  }
  for (const k of kids) if (k) n.append(k);
  return n;
};

let ROWS = [];
const SORTS = [
  ['popularity.desc', '热度 ↓'],
  ['vote_average.desc', '评分 ↓'],
  ['primary_release_date.desc', '上映日期 ↓'],
  ['first_air_date.desc', '首播日期 ↓'],
  ['vote_count.desc', '评分人数 ↓'],
  ['revenue.desc', '票房 ↓'],
];

async function call(path, opts = {}) {
  const res = await fetch(API + path, {
    method: opts.method || 'GET',
    headers: opts.body ? { 'Content-Type': 'application/json' } : undefined,
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok || data.ok === false) throw new Error((data && data.error) || `HTTP ${res.status}`);
  return data;
}

/**
 * 把用户在本机挑的一张图，裁成 16:9（居中裁切）并压成 jpeg，返回 { data(base64), w, h, bytes }。
 *
 * 为什么在浏览器里做：设置页里跑的是真浏览器，`<img>` + `<canvas>` 什么格式都能读（png/webp/heic…）；
 * 而插件跑在面板的 node 进程里、**没有任何图像库**，连 png 都解不了。裁剪与压缩放在这一侧，
 * 插件那头就只剩"把字节写进文件"这一件事。
 *
 * 尺寸取 1280×720：客户端媒体库的瓦片是块大图，1280 宽在手机与电视上都够；q0.82 大约 150~350KB。
 */
function readLocalCover(file) {
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onerror = () => reject(new Error('读不出这个文件'));
    fr.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('这不是浏览器能识别的图片'));
      img.onload = () => {
        try {
          const W = 1280;
          const H = 720;
          const cv = document.createElement('canvas');
          cv.width = W;
          cv.height = H;
          const cx = cv.getContext('2d');
          // 居中裁切：按原图比例贴满 16:9，多出来的部分裁掉（不拉伸、不留黑边）
          const scale = Math.max(W / img.width, H / img.height);
          const dw = img.width * scale;
          const dh = img.height * scale;
          cx.drawImage(img, (W - dw) / 2, (H - dh) / 2, dw, dh);
          const url = cv.toDataURL('image/jpeg', 0.82);
          const data = url.replace(/^data:[^,]*,/, '');
          resolve({ data, w: img.width, h: img.height, bytes: Math.round((data.length * 3) / 4) });
        } catch (e) {
          reject(e);
        }
      };
      img.src = String(fr.result || '');
    };
    fr.readAsDataURL(file);
  });
}

function say(id, text, bad) {  const m = $(id);
  m.textContent = text || '';
  m.style.color = bad ? 'var(--bad,#b3261e)' : 'var(--ok,#0f7b4f)';
}

function fillConn(state) {
  const s = state.settings || {};
  $('language').value = s.language || 'zh-CN';
  $('apiBase').value = s.apiBase || '';
  $('imageBase').value = s.imageBase || '';
  const t = s.token || {};
  $('tokenState').textContent = t.set ? `已配置（${t.length}）` : '未配置';
  $('tokenState').className = 'badge' + (t.set ? ' ok' : '');
}

/* 展开状态跟着**行对象**记（WeakSet）：调顺序会整表重排，重排后原来的展开状态还在 */
const OPEN = new WeakSet();
/* 保存后 ROWS 会整个换成服务端返回的新对象，WeakSet 认不出来 —— 再按行 id 记一份，
 * 这样保存完原来展开的那行还是展开的，不用重新点。 */
const OPEN_IDS = new Set();

function rowCard(row, idx) {
  const d = row.discover || {};
  const card = el('div', { class: 'rowcard' });

  /* 一张卡展开有一屏多高，而"上移/下移"原来压在卡片最底下 —— 想调个顺序得先滚到底，
   * 十几个库挨着调非常难弄。所以：卡片默认**收起**成一行摘要，排序按钮搬到标题右侧
   * 一直在手边，要改字段再点「展开」。 */
  const isOpen = () => OPEN.has(row) || (!!row.id && OPEN_IDS.has(row.id));
  const btnOpen = el('button', { class: 'btn mini', text: isOpen() ? '收起' : '展开' });
  const head = el('h4', {},
    el('span', { class: 'rtitle', text: row.title || '(未命名)' }),
    el('span', { class: 'muted', text: row.id }),
    row.feed ? el('span', { class: 'muted', text: '· 轮播' + (row.randomPage ? ` · 随机 ${row.randomPage} 页` : '') }) : null,
    row.cover ? el('span', { class: 'muted', text: '· 自定义封面' }) : null,
    el('span', { class: 'headops' },
      el('button', { class: 'btn mini', text: '↑', title: '上移一位', onclick: () => move(idx, -1) }),
      el('button', { class: 'btn mini', text: '↓', title: '下移一位', onclick: () => move(idx, 1) }),
      el('button', {
        class: 'btn mini', text: '删除',
        onclick: () => { if (confirm(`删除「${row.title || row.id}」？`)) { ROWS.splice(idx, 1); renderRows(); } },
      }),
      btnOpen),
  );
  /* 收起时看得到的一行摘要：不展开也知道这个库是什么口径 */
  const summary = el('div', { class: 'muted rsum', text: rowSummary(row) });
  const body = el('div', { class: 'rowbody' });
  card.append(head, summary, body);

  const setOpen = (on) => {
    body.classList.toggle('hide', !on);
    summary.classList.toggle('hide', on);
    btnOpen.textContent = on ? '收起' : '展开';
    if (on) {
      OPEN.add(row);
      if (row.id) OPEN_IDS.add(row.id);
    } else {
      OPEN.delete(row);
      if (row.id) OPEN_IDS.delete(row.id);
    }
  };
  btnOpen.addEventListener('click', () => setOpen(!isOpen()));
  setOpen(isOpen());

  /* 字段分区：每段一个小标题 + 一个自适应网格。
   * 一行有十几个字段，平铺成一片输入框看不出层次 —— 按「基本信息 → 筛选条件 → 取数与缓存」
   * 分开，扫一眼就知道哪个该改。 */
  const sect = (title) => {
    body.append(el('div', { class: 'secname', text: title }));
    const g = el('div', { class: 'grid' });
    body.append(g);
    return g;
  };
  const field = (g, label, node) => {
    g.append(el('div', {}, el('label', { text: label }), node));
    return node;
  };
  const txt = (val, ph) => { const i = el('input', { type: 'text', value: val || '' }); if (ph) i.placeholder = ph; return i; };

  const gBasic = sect('基本信息');
  const tTitle = field(gBasic, '显示名', txt(row.title));
  const selMedia = field(gBasic, '类型', (() => {
    const s = el('select', {});
    s.append(el('option', { value: 'movie', text: '电影' }), el('option', { value: 'tv', text: '剧集' }));
    s.value = row.media || 'movie';
    return s;
  })());
  const tLang = field(gBasic, '语言（zh / en / ja|ko）', txt(d.with_original_language, 'zh'));
  const selSort = field(gBasic, '排序', (() => {
    const s = el('select', {});
    for (const [v, t] of SORTS) s.append(el('option', { value: v, text: t }));
    if (d.sort_by && !SORTS.some(([v]) => v === d.sort_by)) s.append(el('option', { value: d.sort_by, text: d.sort_by }));
    s.value = d.sort_by || 'popularity.desc';
    return s;
  })());

  const gFilter = sect('筛选条件');
  const tGenres = field(gFilter, '包含类型（16,35）', txt(d.with_genres, '16'));
  const tWithout = field(gFilter, '排除类型', txt(d.without_genres, '16,99,10763,10764,10767'));
  const tCountry = field(gFilter, '国家/地区（CN,JP）', txt(d.with_origin_country, ''));
  const tMaxRt = field(gFilter, '剧类：剔除每集 ≤ N 分钟（0 = 关）', (() => { const i = el('input', { type: 'number', min: '0', max: '120', value: String(row.maxRuntime || 0) }); return i; })());
  const tVote = field(gFilter, '最低评分人数（vote_count.gte）', txt(d['vote_count.gte'], '0'));
  const selRecent = field(gFilter, '年份窗口', (() => {
    const s = el('select', {});
    for (const [v, t] of [['0', '不限'], ['1', '近一年'], ['3', '近三年'], ['5', '近五年'], ['10', '近十年']]) s.append(el('option', { value: v, text: t }));
    s.value = String(row.recent || 0);
    return s;
  })());

  const gFetch = sect('取数与缓存');
  const tPage = field(gFetch, '每页条数', (() => { const i = el('input', { type: 'number', min: '1', max: '200', value: String(row.pageSize || 20) }); return i; })());
  const tCache = field(gFetch, '缓存秒数', (() => { const i = el('input', { type: 'number', min: '0', max: '86400', value: String(row.cacheDuration || 0) }); return i; })());

  /* ---- 首页轮播 ----
   * 客户端首页顶部那条大图（Rex 之类的皮肤）不带库 Id，只认**声明了 feed 的行** ——
   * 所以它本质是「这一行给不给轮播供图」的开关，外加一个随机翻页。
   * 勾选框、联动的那一项、说明排在同一行里；塞进上面的网格会让两边都挤得读不懂。 */
  body.append(el('div', { class: 'secname', text: '首页轮播' }));
  const chkFeed = el('input', { type: 'checkbox' });
  chkFeed.checked = row.feed === 'random';
  const tRand = el('input', { type: 'number', min: '0', max: '50', value: String(row.randomPage || 0) });
  const randWrap = el('label', { class: 'randwrap' },
    el('span', { class: 'muted', text: '随机翻页' }), tRand,
    el('span', { class: 'muted', text: '1..N 每次随机取一页 · 0 = 固定第一页' }));
  const syncFeed = () => {
    tRand.disabled = !chkFeed.checked;
    randWrap.classList.toggle('off', !chkFeed.checked);
  };
  chkFeed.addEventListener('change', syncFeed);
  syncFeed();
  body.append(el('div', { class: 'feedrow' },
    el('label', { class: 'chk' }, chkFeed, el('span', { text: '用在客户端首页顶部的轮播大图' })),
    randWrap));
  body.append(el('div', { class: 'muted feedhint', text: '不勾这行就没有轮播素材；整套配置里只勾一行' }));

  /* ---- 库封面：这一行作为「媒体库」时显示的那张图（可选）----
   * 留空 = 由面板自己在这一行的内容里找一张（老行为）。
   * 想指定就从这一行现有的内容里点一张，或直接粘一个图片地址。 */
  const tCover = txt(row.cover, 'https://… 或 /api/emby/img/…（留空 = 自动）');
  /* ⚠️ 没有封面时**不能**给 img 一个空 src：空 src 会被浏览器当成"当前文档地址"，
   * 于是页面自己请求自己、无限循环（本地预览就把标签页卡死了，实测）。
   * 所以 src 只在有值时设，清除时 removeAttribute。 */
  const coverThumb = el('img', { class: 'coverthumb', alt: '' });
  const showThumb = (v) => {
    /* 库里存的是 `plugin-file:<插件>/cover/<文件名>` —— 这是给**面板**看的引用，
     * 浏览器不认（不是 http 地址），直接塞给 img 只会是破图。同源问插件要字节，
     * 拼成 data: URL 才画得出来。设置页刚上传完的图也有这条路径，最省事。 */
    const pf = /^plugin-file:[^/]+\/cover\/([^/]+)$/.exec(String(v || ''));
    if (pf) {
      coverThumb.dataset.pending = pf[1];
      coverThumb.style.display = '';
      call('/cover/get', { method: 'POST', body: { name: pf[1] } })
        .then((r) => {
          if (coverThumb.dataset.pending !== pf[1]) return; // 期间又换了别的图，别覆盖
          coverThumb.src = 'data:' + (r.type || 'image/jpeg') + ';base64,' + r.data;
        })
        .catch(() => { coverThumb.removeAttribute('src'); });
      return;
    }
    delete coverThumb.dataset.pending;
    if (v) { coverThumb.src = v; coverThumb.style.display = ''; }
    else { coverThumb.removeAttribute('src'); coverThumb.style.display = 'none'; }
  };
  showThumb(row.cover);
  /* ---- 从本地文件读：在自己设备上挑一张图 → 裁成 16:9 → 重压成 jpeg 交给插件存起来 ----
   * 裁剪/压缩放在**浏览器**里做（canvas）：设置页要什么图都能读（png/webp/heic…），
   * 而插件跑在面板的 node 进程里、**没有任何图像库**，它只负责把那串字节落盘。 */
  const fileInput = el('input', { type: 'file', accept: 'image/*', style: 'display:none' });
  const btnLocal = el('button', { class: 'btn mini', text: '上传本地图片', onclick: () => fileInput.click() });
  fileInput.addEventListener('change', async () => {
    const f = fileInput.files && fileInput.files[0];
    fileInput.value = ''; // 同一张图连挑两次也要触发
    if (!f) return;
    try {
      coverMsg.textContent = '处理图片…';
      const shot = await readLocalCover(f);
      // 新行可能还没有 id（服务端会给），这里先生成一个同形状的，免得文件名没归属
      if (!row.id) row.id = 'row-' + Math.random().toString(16).slice(2, 8);
      const r = await call('/cover/upload', { method: 'POST', body: { rowId: row.id, ext: 'jpg', data: shot.data } });
      setCover(r.cover);
      coverMsg.textContent = `已读入（${shot.w}×${shot.h}，${Math.round(shot.bytes / 1024)}KB，原样保存不配字）· 记得点下面的保存`;
    } catch (e) {
      coverMsg.textContent = '读图失败：' + e.message;
    }
  });
  const strip = el('div', { class: 'strip' });
  const coverMsg = el('span', { class: 'muted covermsg' });
  const setCover = (v) => {
    tCover.value = v || '';
    showThumb(v);
  };
  tCover.addEventListener('input', () => setCover(tCover.value.trim()));
  const btnPick = el('button', {
    class: 'btn mini', text: '从本库挑一张',
    onclick: async () => {
      coverMsg.textContent = '取候选图…';
      strip.textContent = '';
      try {
        const r = await call('/preview', { method: 'POST', body: { row: collect() } });
        const pics = (r.items || []).filter((x) => x.backdrop);
        if (!pics.length) { coverMsg.textContent = '这个库里没有带横图的内容'; return; }
        for (const it of pics) {
          strip.append(el('img', {
            class: 'cand', src: it.thumb || it.backdrop, title: `${it.title}(${it.year})·点选后自动烤字`,
            onclick: async () => {
              coverMsg.textContent = `正在烤封面：${it.title}…`;
              try {
                // 交给插件取图 + 压暗 + 烤库名（和出厂那批封面同款），只把烤好的图存下来
                const rr = await call('/cover/pick', { method: 'POST', body: { rowId: row.id, url: it.backdrop } });
                setCover(rr.cover);
                const extra = rr.baked ? `已烤字「${rr.label}」` : (rr.note || '未烤字');
                coverMsg.textContent = `已选：${it.title} · ${extra} · ${Math.round((rr.bytes || 0) / 1024)}KB/${rr.ms || 0}ms · 记得点下面的保存`;
              } catch (e) {
                coverMsg.textContent = '烤封面失败：' + e.message;
              }
            },
          }));
        }
        coverMsg.textContent = `点一张作为封面（共 ${pics.length} 张候选，选完会自动压暗并配上库名）`;
      } catch (e) { coverMsg.textContent = '取候选图失败：' + e.message; }
    },
  });
  body.append(el('div', { class: 'secname', text: '库封面' }), el('label', {
    class: 'muted extralabel', text: '客户端「媒体库」里显示的那张图（留空 = 面板自动在图库里找一张）',
  }),
    el('div', { class: 'coverbox' }, coverThumb, el('div', { class: 'covertools' }, tCover,
      el('div', { class: 'ops' }, btnPick, btnLocal, el('button', { class: 'btn mini', text: '清除', onclick: () => { setCover(''); coverMsg.textContent = '已清除（保存后生效）'; } })),
      el('div', { class: 'muted coverhint', text: '「从本库挑一张」= 用这个库里的内容图，自动压暗并配上库名；「上传本地图片」= 原样使用，不加字' }))),
    fileInput, strip, coverMsg,
  );

  // 额外参数（JSON）
  const extra = el('textarea', { rows: '2', placeholder: '{"vote_average.gte":"7","with_companies":"420"}' });
  const KNOWN = new Set(['with_original_language', 'with_genres', 'without_genres', 'with_origin_country', 'sort_by', 'vote_count.gte']);
  const rest = {};
  for (const [k, v] of Object.entries(d)) if (!KNOWN.has(k)) rest[k] = v;
  extra.value = Object.keys(rest).length ? JSON.stringify(rest) : '';
  body.append(el('div', { class: 'secname', text: '额外参数' }),
    el('label', { class: 'muted extralabel', text: '直接并进 TMDB 的 /discover 参数（JSON，可留空）' }), extra);

  const out = el('span', { class: 'muted' });
  const ops = el('div', { class: 'ops' },
    el('button', {
      class: 'btn mini', text: '试跑',
      onclick: async () => {
        out.textContent = '试跑中…';
        try {
          const r = await call('/preview', { method: 'POST', body: { row: collect() } });
          out.textContent = `共 ${r.total} 条 · ${(r.items || []).map((x) => `${x.title}(${x.year})`).slice(0, 4).join('、')}`;
        } catch (e) {
          out.textContent = '失败：' + e.message;
        }
      },
    }),
  );
  body.append(ops, out);

  function collect() {
    const discover = {
      with_original_language: tLang.value.trim(),
      with_genres: tGenres.value.trim(),
      without_genres: tWithout.value.trim(),
      with_origin_country: tCountry.value.trim(),
      sort_by: selSort.value,
    };
    if (tVote.value.trim() && tVote.value.trim() !== '0') discover['vote_count.gte'] = tVote.value.trim();
    for (const k of Object.keys(discover)) if (!discover[k]) delete discover[k];
    if (extra.value.trim()) {
      try {
        Object.assign(discover, JSON.parse(extra.value));
      } catch (e) {
        throw new Error('额外参数不是合法 JSON');
      }
    }
    return {
      id: row.id,
      title: tTitle.value.trim() || '未命名库',
      media: selMedia.value,
      maxRuntime: Math.max(0, Number(tMaxRt.value) || 0),
      feed: chkFeed.checked ? 'random' : '',
      randomPage: chkFeed.checked ? Math.max(0, Number(tRand.value) || 0) : 0,
      discover,
      recent: Number(selRecent.value) || 0,
      pageSize: Number(tPage.value) || 20,
      cacheDuration: Number(tCache.value) || 0,
      cover: tCover.value.trim(),
    };
  }

  card.collect = collect;
  return card;
}

/* 收起状态那一行摘要：影/剧 · 语言 · 年份窗口 · 排序 · 每页 */
function rowSummary(row) {
  const d = row.discover || {};
  const bits = [row.media === 'tv' ? '剧集' : '电影'];
  if (d.with_original_language) bits.push('语言 ' + d.with_original_language);
  if (row.recent) bits.push('近 ' + row.recent + ' 年');
  if (d['vote_count.gte']) bits.push('评分人数 ≥ ' + d['vote_count.gte']);
  const hit = SORTS.find(([v]) => v === d.sort_by);
  bits.push('排序 ' + (hit ? hit[1] : (d.sort_by || 'popularity.desc')));
  bits.push(`每页 ${row.pageSize || 20}`);
  return bits.join(' · ');
}

/* 把当前输入框里的改动收回 ROWS。整表重排（调顺序/增删）前必须先走这一步，
 * 否则"改了两行 → 想调顺序 → 一点上移，刚改的全被重建冲掉了"。
 * 额外参数写错 JSON 时只跳过这一行并提示，不覆盖它原有的值。 */
function syncFromDom() {
  const cards = [...$('rowsOut').children];
  cards.forEach((c, i) => {
    if (!ROWS[i]) return;
    try {
      Object.assign(ROWS[i], c.collect()); // 原地合并：对象身份不变，展开状态（WeakSet）才留得住
    } catch (e) {
      say('rowsMsg', `第 ${i + 1} 行没收回：${e.message}`, true);
    }
  });
}

function move(idx, delta) {
  const to = idx + delta;
  if (to < 0 || to >= ROWS.length) return;
  syncFromDom();
  const [x] = ROWS.splice(idx, 1);
  ROWS.splice(to, 0, x);
  renderRows();
}

function renderRows() {
  const host = $('rowsOut');
  host.textContent = '';
  ROWS.forEach((row, idx) => host.append(rowCard(row, idx)));
}

function collectAll() {
  const cards = [...$('rowsOut').children];
  return cards.map((c) => c.collect());
}

/* 改动提醒：行区里任何输入都提示"还没保存"，免得改完直接关页面 */
$('rowsOut').addEventListener('input', () => say('rowsMsg', '有未保存的改动 · 记得点「保存全部」'));
$('rowsOut').addEventListener('change', () => say('rowsMsg', '有未保存的改动 · 记得点「保存全部」'));

$('addRow').addEventListener('click', () => {
  const fresh = {
    id: '', title: '新库', media: 'movie',
    discover: { sort_by: 'popularity.desc' }, recent: 5, pageSize: 20, cacheDuration: 1800,
  };
  ROWS.push(fresh);
  OPEN.add(fresh); // 新加的这行直接展开，省得还要点一下
  renderRows();
});

$('saveRows').addEventListener('click', async () => {
  try {
    const rows = collectAll();
    const r = await call('/rows', { method: 'POST', body: { rows } });
    ROWS = r.rows || rows;
    renderRows();
    say('rowsMsg', '已保存（面板 5 秒内生效）');
  } catch (e) {
    say('rowsMsg', '保存失败：' + e.message, true);
  }
});

$('resetRows').addEventListener('click', async () => {
  if (!confirm('恢复成出厂 9 个库？当前自定义会被覆盖。')) return;
  try {
    const r = await call('/rows/reset', { method: 'POST', body: {} });
    ROWS = r.rows || [];
    renderRows();
    say('rowsMsg', '已恢复出厂');
  } catch (e) {
    say('rowsMsg', '失败：' + e.message, true);
  }
});

$('saveConn').addEventListener('click', async () => {
  const body = { language: $('language').value.trim(), apiBase: $('apiBase').value.trim(), imageBase: $('imageBase').value.trim() };
  const t = $('token').value.trim();
  if (t) body.token = t;
  try {
    await call('/settings', { method: 'POST', body });
    $('token').value = '';
    say('msg', '已保存');
    await load();
  } catch (e) {
    say('msg', '保存失败：' + e.message, true);
  }
});

$('test').addEventListener('click', async () => {
  $('out').textContent = '测试中…';
  try {
    const r = await call('/test', { method: 'POST', body: {} });
    $('out').textContent = `连通 · 电影总数 ${r.total} · 示例「${r.sample || '-'}」`;
  } catch (e) {
    $('out').textContent = '失败：' + e.message;
  }
});

async function load() {
  try {
    const st = await call('/state');
    fillConn(st);
    ROWS = st.rows || [];
    renderRows();
  } catch (e) {
    say('msg', '读取失败：' + e.message, true);
  }
}

load();

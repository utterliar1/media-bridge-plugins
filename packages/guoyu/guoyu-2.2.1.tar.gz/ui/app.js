/* 我的片库 · 设置页：行完全可编辑（增删/排序/筛选/试跑） */
const API = location.pathname.replace(/\/ui\/.*$/, '') + '/api';
const $ = (id) => document.getElementById(id);
const el = (tag, attrs, ...kids) => {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k === 'class') n.className = v;
    else if (k === 'text') n.textContent = v;
    else if (k === 'html') n.innerHTML = v;
    else if (k.startsWith('on') && typeof v === 'function') n.addEventListener(k.slice(2), v);
    /* ↑ 事件必须 addEventListener：setAttribute('onclick', fn) 只会把函数 toString 成属性字符串，
     *   点击时什么也不会发生（试跑/上移/下移/删除这几个按钮一直没生效就是它）。 */
    else n.setAttribute(k, v);
  }
  for (const k of kids) if (k) n.append(k);
  return n;
};

let ROWS = [];
const SORTS = [
  ['popularity.desc', '热度 ↓'],
  ['vote_average.desc', '评分 ↓'],
  ['primary_release_date.desc', '上映日期 ↓'],
  ['first_air_date.desc', '首播日期 ↓'],
  ['vote_count.desc', '评分人数 ↓'],
  ['revenue.desc', '票房 ↓'],
];

async function call(path, opts = {}) {
  const res = await fetch(API + path, {
    method: opts.method || 'GET',
    headers: opts.body ? { 'Content-Type': 'application/json' } : undefined,
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok || data.ok === false) throw new Error((data && data.error) || `HTTP ${res.status}`);
  return data;
}

function say(id, text, bad) {
  const m = $(id);
  m.textContent = text || '';
  m.style.color = bad ? 'var(--bad,#b3261e)' : 'var(--ok,#0f7b4f)';
}

function fillConn(state) {
  const s = state.settings || {};
  $('language').value = s.language || 'zh-CN';
  $('apiBase').value = s.apiBase || '';
  $('imageBase').value = s.imageBase || '';
  const t = s.token || {};
  $('tokenState').textContent = t.set ? `已配置（${t.length}）` : '未配置';
  $('tokenState').className = 'badge' + (t.set ? ' ok' : '');
}

function rowCard(row, idx) {
  const d = row.discover || {};
  const card = el('div', { class: 'rowcard' });
  const head = el('h4', {},
    el('span', { text: row.title || '(未命名)' }),
    el('span', { class: 'muted', text: row.id }),
  );
  card.append(head);

  const grid = el('div', { class: 'grid' });
  const field = (label, node) => {
    const w = el('div', {}, el('label', { text: label }), node);
    grid.append(w);
    return node;
  };
  const txt = (val, ph) => { const i = el('input', { type: 'text', value: val || '' }); if (ph) i.placeholder = ph; return i; };

  const tTitle = field('显示名', txt(row.title));
  const selMedia = field('类型', (() => {
    const s = el('select', {});
    s.append(el('option', { value: 'movie', text: '电影' }), el('option', { value: 'tv', text: '剧集' }));
    s.value = row.media || 'movie';
    return s;
  })());
  const tLang = field('语言（zh / en / ja|ko）', txt(d.with_original_language, 'zh'));
  const tGenres = field('包含类型（16,35）', txt(d.with_genres, '16'));
  const tWithout = field('排除类型', txt(d.without_genres, '16,99,10763,10764,10767'));
  const tCountry = field('国家/地区（CN,JP）', txt(d.with_origin_country, ''));
  const selSort = field('排序', (() => {
    const s = el('select', {});
    for (const [v, t] of SORTS) s.append(el('option', { value: v, text: t }));
    if (d.sort_by && !SORTS.some(([v]) => v === d.sort_by)) s.append(el('option', { value: d.sort_by, text: d.sort_by }));
    s.value = d.sort_by || 'popularity.desc';
    return s;
  })());
  const tVote = field('最低评分人数（vote_count.gte）', txt(d['vote_count.gte'], '0'));
  const selRecent = field('年份窗口', (() => {
    const s = el('select', {});
    for (const [v, t] of [['0', '不限'], ['1', '近一年'], ['3', '近三年'], ['5', '近五年'], ['10', '近十年']]) s.append(el('option', { value: v, text: t }));
    s.value = String(row.recent || 0);
    return s;
  })());
  const tPage = field('每页条数', (() => { const i = el('input', { type: 'number', min: '1', max: '200', value: String(row.pageSize || 20) }); return i; })());
  const tCache = field('缓存秒数', (() => { const i = el('input', { type: 'number', min: '0', max: '86400', value: String(row.cacheDuration || 0) }); return i; })());
  const tMaxRt = field('剧类：剔除每集≤N分钟（0=关）', (() => { const i = el('input', { type: 'number', min: '0', max: '120', value: String(row.maxRuntime || 0) }); return i; })());
  card.append(grid);

  // 额外参数（JSON）
  const extra = el('textarea', { rows: '2', placeholder: '{"vote_average.gte":"7","with_companies":"420"}' });
  const KNOWN = new Set(['with_original_language', 'with_genres', 'without_genres', 'with_origin_country', 'sort_by', 'vote_count.gte']);
  const rest = {};
  for (const [k, v] of Object.entries(d)) if (!KNOWN.has(k)) rest[k] = v;
  extra.value = Object.keys(rest).length ? JSON.stringify(rest) : '';
  card.append(el('label', { class: 'muted', text: '额外参数（JSON，可留空）' }), extra);

  const out = el('span', { class: 'muted' });
  const ops = el('div', { class: 'ops' },
    el('button', {
      class: 'btn mini', text: '试跑',
      onclick: async () => {
        out.textContent = '试跑中…';
        try {
          const r = await call('/preview', { method: 'POST', body: { row: collect() } });
          out.textContent = `共 ${r.total} 条 · ${(r.items || []).map((x) => `${x.title}(${x.year})`).slice(0, 4).join('、')}`;
        } catch (e) {
          out.textContent = '失败：' + e.message;
        }
      },
    }),
    el('button', { class: 'btn mini', text: '↑ 上移', onclick: () => move(idx, -1) }),
    el('button', { class: 'btn mini', text: '↓ 下移', onclick: () => move(idx, 1) }),
    el('button', {
      class: 'btn mini', text: '删除',
      onclick: () => { if (confirm(`删除「${row.title || row.id}」？`)) { ROWS.splice(idx, 1); renderRows(); } },
    }),
  );
  card.append(ops, out);

  function collect() {
    const discover = {
      with_original_language: tLang.value.trim(),
      with_genres: tGenres.value.trim(),
      without_genres: tWithout.value.trim(),
      with_origin_country: tCountry.value.trim(),
      sort_by: selSort.value,
    };
    if (tVote.value.trim() && tVote.value.trim() !== '0') discover['vote_count.gte'] = tVote.value.trim();
    for (const k of Object.keys(discover)) if (!discover[k]) delete discover[k];
    if (extra.value.trim()) {
      try {
        Object.assign(discover, JSON.parse(extra.value));
      } catch (e) {
        throw new Error('额外参数不是合法 JSON');
      }
    }
    return {
      id: row.id,
      title: tTitle.value.trim() || '未命名库',
      media: selMedia.value,
      maxRuntime: Math.max(0, Number(tMaxRt.value) || 0),
      discover,
      recent: Number(selRecent.value) || 0,
      pageSize: Number(tPage.value) || 20,
      cacheDuration: Number(tCache.value) || 0,
    };
  }

  card.collect = collect;
  return card;
}

function move(idx, delta) {
  const to = idx + delta;
  if (to < 0 || to >= ROWS.length) return;
  const [x] = ROWS.splice(idx, 1);
  ROWS.splice(to, 0, x);
  renderRows();
}

function renderRows() {
  const host = $('rowsOut');
  host.textContent = '';
  ROWS.forEach((row, idx) => host.append(rowCard(row, idx)));
}

function collectAll() {
  const cards = [...$('rowsOut').children];
  return cards.map((c) => c.collect());
}

$('addRow').addEventListener('click', () => {
  ROWS.push({
    id: '', title: '新库', media: 'movie',
    discover: { sort_by: 'popularity.desc' }, recent: 5, pageSize: 20, cacheDuration: 1800,
  });
  renderRows();
});

$('saveRows').addEventListener('click', async () => {
  try {
    const rows = collectAll();
    const r = await call('/rows', { method: 'POST', body: { rows } });
    ROWS = r.rows || rows;
    renderRows();
    say('rowsMsg', '已保存（面板 5 秒内生效）');
  } catch (e) {
    say('rowsMsg', '保存失败：' + e.message, true);
  }
});

$('resetRows').addEventListener('click', async () => {
  if (!confirm('恢复成出厂 9 个库？当前自定义会被覆盖。')) return;
  try {
    const r = await call('/rows/reset', { method: 'POST', body: {} });
    ROWS = r.rows || [];
    renderRows();
    say('rowsMsg', '已恢复出厂');
  } catch (e) {
    say('rowsMsg', '失败：' + e.message, true);
  }
});

$('saveConn').addEventListener('click', async () => {
  const body = { language: $('language').value.trim(), apiBase: $('apiBase').value.trim(), imageBase: $('imageBase').value.trim() };
  const t = $('token').value.trim();
  if (t) body.token = t;
  try {
    await call('/settings', { method: 'POST', body });
    $('token').value = '';
    say('msg', '已保存');
    await load();
  } catch (e) {
    say('msg', '保存失败：' + e.message, true);
  }
});

$('test').addEventListener('click', async () => {
  $('out').textContent = '测试中…';
  try {
    const r = await call('/test', { method: 'POST', body: {} });
    $('out').textContent = `连通 · 电影总数 ${r.total} · 示例「${r.sample || '-'}」`;
  } catch (e) {
    $('out').textContent = '失败：' + e.message;
  }
});

async function load() {
  try {
    const st = await call('/state');
    fillConn(st);
    ROWS = st.rows || [];
    renderRows();
  } catch (e) {
    say('msg', '读取失败：' + e.message, true);
  }
}

load();
